export class User {
	id: string;
	nombre: string;
	email: string;
	pais: string;
	password: string;
	titulo:string;

}
